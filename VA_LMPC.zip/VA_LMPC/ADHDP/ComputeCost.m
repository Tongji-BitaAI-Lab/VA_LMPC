function [ Qfun] = ComputeCost( x_real,u_real,Q,R)
    % ComputeCost 

    Cost =[];
    for i = 1:(size(x_real,2))
    Index = size(x_real,2)-i+1; % Need to start from the end
    % use norm 1 or norm 2

                if i == 1
                    Cost(Index) = (x_real(:,Index))'*Q*(x_real(:,Index)); 
%                     Cost(Index) = 0;
                else
                    Cost(Index) = Cost(Index+1) + (x_real(:,Index))'*Q*(x_real(:,Index)) + u_real(:,Index)'*R*u_real(:,Index); 
                end

Qfun = Cost;
end

