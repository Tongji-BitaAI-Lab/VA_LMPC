%%%%%% system model %%%% 2016.06.12
function [U, x_n] = system_1(x, u)

%% system 2
A = [1 1; 0 1];
B = [0 ; -1];

x_n = A*x + B*u;
%% system 1
% x1 = x(1);
% x2 = x(2);
%     f = [x2;
%          (1-x1^2)*x2-x1];
%     g = [ 0;
%           1];
% dx = f + g * u; %dx/dt
% x_n = dx*0.02 + x;      
if norm(x)>=0.01
U = x' *[100 0; 0 100]* x + 0.5*u * u;
%     U = 0.5;
else
    U = 0;
end
end


