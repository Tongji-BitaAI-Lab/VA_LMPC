%%%%%% network training %%%% 2016.06.12

global lc
global la
global gamma

lc = 0.3;
la = 0.3;
gamma = 0.99;

x = [-14, 2]';
u = 0;
J = 1;
U = 4;

%%% critic network initialization
network_c = [size(x,1)+1, 5, 1];

Wc1_f = 0.5 * rand(network_c(2),network_c(1))-0.5;
Wc2_f = 0.5 * rand(network_c(2),network_c(3))-0.5;
Wc1 = Wc1_f;
Wc2 = Wc2_f;

%%% action network initialization
network_a = [size(x,1), 5, 1];

Wa1_f = 0.5 * rand(network_a(2),network_a(1))-0.3;
Wa2_f = 0.5 * rand(network_a(2),network_a(3))-0.3;
Wa1 = Wa1_f;
Wa2 = Wa2_f;


simulation_time = 100;
J_plot = [];
x_plot = [];
u_plot = [];
Deviation_plot = [];
LoL_plot = [];
x_plot(:,1) = x;
for t = 1:simulation_time;
    u = u/3;
    [Wc1_1, Wc2_1, J_1, p] = critic_network(x, u, Wc1, Wc2, J, U);
    [u_1, Wa1_1, Wa2_1] = action_network(x', Wa1, Wa2, Wc1_1, Wc2_1, J_1, p);
%  
    u_1 = 3*u_1;
    uhis(t) = u_1;
    [U, x] = system_1(x,u_1);
    U = U;
    J = J_1;
    u = u_1;
    
    J_plot(1,t) = J_1;
    x_plot(:,t+1) = x;
    u_plot(1,t) = u_1;

    
    
    
    
    Wc1 = Wc1_1;
    Wc2 = Wc2_1;
    Wa1 = Wa1_1;
    Wa2 = Wa2_1;

end
Q_value = ComputeCost(x_plot, u_plot,  100, 0.5)
figure(1)
plot(J_plot)
ylabel('J');

figure(2)
plot(u_plot,'r')
ylabel('U');

figure(3)
plot(x_plot(1,:),x_plot(2,:),'b-o')
hold off
ylabel('trajectory');






