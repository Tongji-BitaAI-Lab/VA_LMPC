
clc 
clear all
A = [1 1; 0 1];
B = [0;-1];
alpha_m=0.1;	   %Learning rate of the modal network
alpha_c=0.1;	   %Learning rate of the critic network
alpha_a=0.1;	    %Learning rate the action network
areafa=0.9;
Uc=0;
N_c=50;  %Internal cycle of the critic network
N_a=50;  %Internal cycle of the action network
T_cError=1e-10;   %Internal training error threshold for the critic network
T_aError=1e-10;   %Internal training error threshold for the action network
T_mError=0.1;   %Internal training error threshold for the model network
N_aHidden = 6;   %Number of action network nodes in hidden layer
N_cHidden = 8;   %Number of critic network nodes in hidden layer
N_mHidden = 8;   %Number of modal network nodes in hidden layer
WA_Inputs = 2;  %ִ����������ڵ���
WC_Inputs = 2;  %������������ڵ���
WM_Inputs = 3;  %������������ڵ���
wm11=(rand(WM_Inputs,N_mHidden)-0.5)*0.5;
wm21=(rand(N_mHidden,2)-0.5)*0.5;
wc11=(rand(WC_Inputs,N_cHidden)-0.5)*0.5;
wc21=(rand(N_cHidden,1)-0.5)*0.5;
wa11=(rand(WA_Inputs,N_aHidden)-0.5)*0.5;
wa21=(rand(N_aHidden,1)-0.5)*0.5;
wc12=(rand(WC_Inputs,N_cHidden)-0.5)*0.5;
wc22=(rand(N_cHidden,1)-0.5)*0.5;
wa12=(rand(WA_Inputs,N_aHidden)-0.5)*0.5;
wa22=(rand(N_aHidden,1)-0.5)*0.5;
follower1=[-14,2];
% follower2=[1,-0.3];
% leader=[10,10];
% newSt0=leader;
x_d = [0;0];
newSt1=follower1;
x1(:,1)=newSt1;
Input_a=newSt1-x_d'; % x �� Ref. 
[vm,h,g]=caculAN(Input_a,wa11,wa21);
U1=vm;
udata1(1)=U1;
 for i=1:12
     
        [vm,h,g]=caculAN(Input_a,wa11,wa21);
        U1=vm;
        udata1(i+1)=U1;
        newSt1=system(newSt1,U1); %����Kʱ��x0״̬
        x1(:,i+1)=newSt1;                          %�洢Kʱ��x0״̬
        Input_1c=newSt1-x_d';        %Kʱ��������������e(k)
        Input_a=Input_1c;                         %Kʱ��ִ����������e(k)
        Input_m=[newSt1,U1];                  %Kʱ��ģ����������[x0(k),U1(k)]
        error1=system(newSt1,U1);    %K+1ʱ��x0��ʵֵ
        [Xk1,wm11,wm21,s,h]=caculCM(Input_m,wm11,wm21,T_mError,error1,alpha_m);%Xk1Ϊ������1Ԥ�����һʱ��ֵ
        Input_2c=Xk1-x_d';                  %K+1ʱ��������������e(k+1)
 
        [J2,p,q] = caculCN(Input_2c,wc11,wc21);
        [J1,p,q] = caculCN(Input_1c,wc11,wc21);
        [U1,h,g] = caculAN(Input_a,wa11,wa21);
        
        U_xy=Input_1c*Input_1c'*0.01+U1*U1;
        ec = J1-J2-U_xy;
		Ec = 0.5 * ec^2;
        ceshi=0;
        while(Ec>T_cError&&ceshi<50)
            ceshi=ceshi+1;
            [wc11,wc21]=upCN(alpha_c,ec,p,Input_1c,wc11,wc21);
            [J1,p,q] = caculCN(Input_1c,wc11,wc21);
            ec = J1-J2-U_xy;
            Ec = 0.5 * ec^2;
        end 
            [J2,p,q] = caculCN(Input_2c,wc11,wc21);
            ea= U_xy+J2+Uc;
		    Ea = 0.5 * ea^2;
            ceshi=0;
 while (Ea>T_aError&&ceshi<50)
            ceshi=ceshi+1;
            [wa21,wa11]=upAction( alpha_a,Input_a,vm,ea,q,g,N_aHidden,WC_Inputs,wa11,wa21,wc11,wc21);
            [U1,h,g]=caculAN(Input_a,wa11,wa21);
            Xk1 = A*newSt1'+B*U1;
            Input_2c=Xk1'-x_d';
            [J2,p,q] = caculCN(Input_2c,wc11,wc21);
            U_xy=Input_1c*Input_1c'+U1*U1;
            ea= U_xy+J2+Uc;
		    Ea = 0.5 * ea^2;
 end

        
 end
figure (2)
plot(udata1);
title('����Ӧ�����Ŀ����ɵĹ켣');

figure(1)
plot(x1(1,:),x1(2,:),'r-o');

