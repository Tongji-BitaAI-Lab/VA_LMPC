function X2=TPSystem(X,U)
X2(1)=0.1*X(2)+X(1);
X2(2)=-0.49*sin(X(1))-0.02*X(2)+X(2)+0.1*U;
