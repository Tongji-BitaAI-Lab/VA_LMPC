function [vm,h,g]=caculAN(Input_a,wa1,wa2)
    h=Input_a*wa1;
    g = (1 - exp(-h))./(1 + exp(-h));
    um = g*wa2;
    vm = (1 - exp(-um))./(1 + exp(-um));
end