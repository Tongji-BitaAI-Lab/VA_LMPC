function [Xk,wm1,wm2,s,h]=caculCM(Input_m,wm1,wm2,T_mError,newState,alpha_m)
        s=Input_m*wm1;
        h = (1 - exp(-s))./(1 + exp(-s));
        Xk = h*wm2;
        emodel = Xk-newState;
        em=norm(emodel',2);
        Em = 0.5 * em^2;
        ceshi = 1;
         while (Em>T_mError&&ceshi<50) 
            wm2=wm2-alpha_m*(s'*emodel);
%             wm2=wm2/(max(max(abs(wm2))));
            s=Input_m*wm1;
            h = (1 - exp(-s))./(1 + exp(-s));
            Xk = h*wm2;
            emodel = Xk-newState;
            em=norm(emodel',2);
            Em = 0.5 * em^2;
            ceshi = ceshi+1;
        end   
end