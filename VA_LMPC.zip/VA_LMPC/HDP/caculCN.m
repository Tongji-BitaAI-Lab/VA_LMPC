function [Jc,p,q]=caculCN(Input_1c,wc1,wc2)
q = Input_1c*wc1;
p = (1 - exp(-q))./(1 + exp(-q));
Jc = p*wc2;
end