function X2=ystem(X,U)
A = [1 1; 0 1];
B = [0;-1];
X2 = A*X' + B*U;
X2 = X2';
