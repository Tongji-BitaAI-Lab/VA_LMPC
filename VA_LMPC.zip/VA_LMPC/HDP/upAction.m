function [wa2,wa1]=upAction( alpha_a,Input_a,vm,ea,q,g,N_aHidden,WC_Inputs,wa1,wa2,wc1,wc2)
gradEaJ = ea;
gradJu = 0;
  for  i=1:N_aHidden,
       gradJu = gradJu + wc2(i)*0.5*(1-q(i)^2)*wc1(WC_Inputs,i);
  end           
  for (i=1:N_aHidden),
        graduha2   = 0.5*(1-vm^2)*wa2(i);
        gradha2ha1 = 0.5*(1-g(i)^2);
        gradha1wa1 = Input_a';
        delta_wa1  = -alpha_a*gradEaJ*gradJu*graduha2*gradha2ha1*gradha1wa1;
        wa1(:,i)   = wa1(:,i) + delta_wa1;
   end
        graduwa2 = 0.5*(1-vm^2)*g';
        delta_wa2=-alpha_a*gradEaJ*gradJu*graduwa2;
        wa2 = wa2 + delta_wa2;
        
%         wa2=wa2/(max(max(abs(wa2))));
%         wa1=wa1/(max(max(abs(wa1))));
        wa2=wa2/norm(wa2);
        wa1=wa1/norm(wa1);
end