function [wc1,wc2]=upCN(alpha_c,ec,p,Input_1c,wc1,wc2)
wc2=wc2-alpha_c*ec*p';
wc1=wc1-alpha_c*0.5*ec*Input_1c'*(wc2'.*(1-p.*p));
wc2=wc2/norm(wc2);
wc1=wc1/norm(wc1);

end