
%--------------------------------------------------------------------------
clear all
close all
clc
    dt = 1;
    lr = 0.2; %Learning rate
    Q = 100 * eye(2);
    R = 0.5 * eye(1);
% wcn = [0 0.0567 0 0 0.045 0 0.05 0 0.0501 0.0134]; %Initial weight of the critic NN
wcn =(rands(1,2)-0.5)*0.5;
wcn1 = wcn;
xw = [-14 2]'; %Initial state and weight
figure(1)
plot (xw(1),xw(2),'o')
hold on
x = xw(1:2);
xhis(:,1) = x;
t(:,1) = 0;
t1 = cputime
for i = 1:20
   t(:,i+1) = i*dt;
    
    x1 = x(1);
    x2 = x(2);
%---system dynamics---%
    f = [x2;
          0];
    g = [ 0;
          -1];
   [J1, sigma, dsigma] = cnet(wcn,x);
    %--- PI algorithm---%
    ua = -0.5 * inv(R) * g' * dsigma' * wcn'; %Approximate control law
    uhis(:,i) = ua;
    dx = f + g * ua; %dx/dt
    xn = dx*dt + x;
%     J1 = wcn*sigma;
    cyc =0;
    Ec = 100;
    while ((Ec>0.01)&(cyc<=100))
    [J2, sigma2, ~] = cnet(wcn,xn);
    ec = J1 - J2- x' * Q * x - ua' * R * ua;
%      ec = J1 - J2- (x' * Q * x + ua' * R * ua)/600;
%      ec = J1 - J2- 0.9;
    Ec = 0.5*ec^2;
    dwcn = -lr * ec * sigma2; %Weight updating law
%     wcn  = (wcn + dwcn'+0.2*(wcn-wcn1))/norm(wcn + dwcn'+0.2*(wcn-wcn1));
%     wcn  = (wcn + dwcn'+0.9*(wcn- wcn1))/norm(wcn + dwcn'+0.9*(wcn- wcn1));
    wcn  = (wcn + dwcn')/norm(wcn + dwcn');
%     wcn1 = wcn;
    cyc = cyc+1;
    end
    wcn1 = wcn;
    plot (xn(1),xn(2),'o')
    x = xn;
    xhis(:,i+1)= xn;
end
%--------------------------------------------------------------------------
t2 = cputime;
t3 = t2-t1;
Q_value = ComputeCost(xhis, uhis,  Q, R)
%draw figures---%
figure(2)
hold on
plot( xhis(1, :),xhis(2, :),'-o');

% xhis1(:,1)= xw;
% x = xw(1:2);
% for i = 1:20
%    t(:,i+1) = i*dt;
%     
%     x1 = x(1);
%     x2 = x(2);
% %---system dynamics---%
%     f = [x2;
%           0];
%     g = [ 0;
%           -1];
%    [J1, sigma, dsigma] = cnet(wcn,x);
%     %--- PI algorithm---%
%     ua = -0.5 * inv(R) * g' * dsigma' * wcn'; %Approximate control law
%     dx = f + g * ua; %dx/dt
%     xn = dx*dt + x;
%     
% %     plot (xn(1),xn(2),'o')
%     x = xn;
%     xhis1(:,i+1)= xn;
% end
% %draw figures---%
% figure(3)
% hold on
% plot( xhis1(1, :),xhis1(2, :),'-o');










