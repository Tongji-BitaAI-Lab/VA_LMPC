This code implements a simple LMPC for solving an infinite time optimal control problem. 

It requires YALMIP and MPT. Follow [these](https://www.mpt3.org/Main/Installation) to install the toolboxes.

Please refer to the [PDF README](https://github.com/urosolia/LMPC_SimpleExample/blob/master/PDF_README.pdf)