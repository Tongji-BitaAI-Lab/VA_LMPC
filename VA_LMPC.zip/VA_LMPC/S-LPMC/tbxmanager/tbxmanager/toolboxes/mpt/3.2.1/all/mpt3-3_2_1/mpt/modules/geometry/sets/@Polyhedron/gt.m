function tf = gt(P,S)
% P greater than S

tf = ge(P,S);

end
